
export { default as LayoutPage } from "./Layout"
export { default as HomePage } from "./Home"
export { default as CadastrarPage } from "./Cadastrar"
export { default as LoginPage } from "./Login"

