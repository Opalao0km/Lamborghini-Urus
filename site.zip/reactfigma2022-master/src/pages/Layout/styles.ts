import styled from "styled-components"

export const Layout = styled.div`
  main {
    min-height: 80vh;
  }
`
