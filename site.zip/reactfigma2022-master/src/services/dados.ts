const dados = [
  {
    id: 1,
    nome: "Lázaro",
    data: "27/04/2022 10:08:00",
    titulo: "Blusa",
    mensagem: "Tenho uma blusa para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }]
  },
  {
    id: 2,
    nome: "Luan",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 3,
    nome: "Luana",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 4,
    nome: "Maria",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 5,
    nome: "João",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 6,
    nome: "Kauã",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 7,
    nome: "José",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
  {
    id: 8,
    nome: "Roberto",
    data: "28/04/2022 10:08:00",
    titulo: "Calça",
    mensagem: "Tenho uma calça para doar, alguém interessa?",
    topico: [{
      id: 1,
      item: "Reutilizar"
    }, {
      id: 2,
      item: "Reciclar"
    }, {
      id: 3,
      item: "Doar"
    }]
  },
]

export default dados